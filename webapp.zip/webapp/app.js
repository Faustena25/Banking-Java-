'use strict';

const API_BASE = 'api/account';

document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  loadDashboard();
});

// ── Navigation ────────────────────────────────────────────────────────────────
function initNavigation() {
  document.querySelectorAll('[data-page]').forEach(el => {
    el.addEventListener('click', () => navigateTo(el.dataset.page));
  });
  const ham = document.getElementById('hamburger');
  const sidebar = document.querySelector('.sidebar');
  if (ham) {
    ham.addEventListener('click', () => sidebar.classList.toggle('open'));
    document.querySelector('.main-content').addEventListener('click', () => sidebar.classList.remove('open'));
  }
}

function navigateTo(page) {
  document.querySelectorAll('.nav-item').forEach(el => el.classList.toggle('active', el.dataset.page === page));
  document.querySelectorAll('.page').forEach(el => el.classList.toggle('active', el.id === 'page-' + page));

  const titles = {
    dashboard: ['Dashboard',      'Overview & quick actions'],
    create:    ['Create Account', 'Register a new bank account'],
    view:      ['View Accounts',  'Search and browse accounts'],
    deposit:   ['Deposit Money',  'Add funds to an account'],
    withdraw:  ['Withdraw Money', 'Withdraw funds from an account'],
    status:    ['Account Status', 'Manage account status'],
  };
  const [title, sub] = titles[page] || [page, ''];
  document.getElementById('page-title').textContent    = title;
  document.getElementById('page-subtitle').textContent = sub;

  if (page === 'dashboard') loadDashboard();
  if (page === 'view')      loadAllAccounts();
  document.querySelector('.sidebar')?.classList.remove('open');
}

// ── API ───────────────────────────────────────────────────────────────────────
async function apiGet(params) {
  const res = await fetch(API_BASE + '?' + new URLSearchParams(params));
  if (!res.ok) throw new Error('Network error ' + res.status);
  return res.json();
}

async function apiPost(params) {
  const res = await fetch(API_BASE, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params).toString()
  });
  if (!res.ok) throw new Error('Network error ' + res.status);
  return res.json();
}

// ── Toast ─────────────────────────────────────────────────────────────────────
function showToast(message, type = 'info', duration = 4000) {
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${icons[type] || '📌'}</span><span>${message}</span>`;
  document.getElementById('toast-container').appendChild(toast);
  setTimeout(() => {
    toast.style.animation = 'toastOut 0.3s ease forwards';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// ── Dashboard ─────────────────────────────────────────────────────────────────
async function loadDashboard() {
  try {
    const d = await apiGet({ action: 'dashboard' });
    if (d.success) {
      setEl('stat-total',    d.totalAccounts);
      setEl('stat-active',   d.activeAccounts);
      setEl('stat-inactive', d.inactiveAccounts);
      setEl('stat-closed',   d.closedAccounts);
      setEl('stat-funds',    formatCurrency(d.totalFunds));
    }
  } catch { showToast('Could not load dashboard.', 'error'); }
}

// ── Create Account ────────────────────────────────────────────────────────────
document.getElementById('form-create')?.addEventListener('submit', async function (e) {
  e.preventDefault();
  clearErrors();

  const fields = {
    customerName:   getVal('create-name'),
    email:          getVal('create-email'),
    phone:          getVal('create-phone'),
    address:        getVal('create-address'),
    accountType:    getVal('create-type'),
    initialDeposit: getVal('create-deposit'),
  };

  let valid = true;
  if (!fields.customerName)  { showFE('create-name',    'Name is required.');           valid = false; }
  if (!fields.email)         { showFE('create-email',   'Email is required.');          valid = false; }
  else if (!validEmail(fields.email)) { showFE('create-email', 'Invalid email format.'); valid = false; }
  if (!fields.phone)         { showFE('create-phone',   'Phone is required.');          valid = false; }
  else if (!validPhone(fields.phone)) { showFE('create-phone', 'Invalid phone format.'); valid = false; }
  if (!fields.address)       { showFE('create-address', 'Address is required.');        valid = false; }
  if (!fields.initialDeposit || isNaN(fields.initialDeposit) || +fields.initialDeposit < 0)
    { showFE('create-deposit', 'Enter a valid non-negative amount.'); valid = false; }
  if (!valid) return;

  const btn = this.querySelector('[type=submit]');
  setLoading(btn, true);
  try {
    const d = await apiPost({ action: 'createAccount', ...fields });
    if (d.success) {
      showAlert('create-alert', 'success', `✅ Account created! Number: <strong class="mono">${d.accountNumber}</strong>`);
      showToast('Account created!', 'success');
      this.reset();
    } else {
      showAlert('create-alert', 'error', '❌ ' + d.message);
    }
  } catch { showAlert('create-alert', 'error', '❌ Server error.'); }
  finally   { setLoading(btn, false); }
});

// ── View Accounts ─────────────────────────────────────────────────────────────
async function loadAllAccounts() { await searchAccounts('', ''); }

document.getElementById('form-search')?.addEventListener('submit', async function (e) {
  e.preventDefault();
  await searchAccounts(getVal('search-accnum'), getVal('search-name'));
});

document.getElementById('btn-search-all')?.addEventListener('click', () => {
  document.getElementById('search-accnum').value = '';
  document.getElementById('search-name').value   = '';
  loadAllAccounts();
});

async function searchAccounts(accNum, name) {
  const tbody = document.getElementById('accounts-tbody');
  tbody.innerHTML = `<tr><td colspan="8"><div class="loading-wrap"><div class="spinner"></div></div></td></tr>`;
  try {
    const p = { action: 'searchAccount' };
    if (accNum) p.accountNumber = accNum;
    else if (name) p.customerName = name;
    const d = await apiGet(p);
    if (d.success) renderTable(d.account ? [d.account] : (d.accounts || []));
    else tbody.innerHTML = `<tr><td colspan="8"><div class="empty-state"><div class="icon">🔍</div><p>${d.message || 'No accounts found.'}</p></div></td></tr>`;
  } catch {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;color:var(--ruby)">Error loading accounts.</td></tr>`;
  }
}

function renderTable(accounts) {
  const tbody = document.getElementById('accounts-tbody');
  if (!accounts.length) {
    tbody.innerHTML = `<tr><td colspan="8"><div class="empty-state"><div class="icon">🏦</div><p>No accounts found.</p></div></td></tr>`;
    return;
  }
  tbody.innerHTML = accounts.map(a => `
    <tr>
      <td><span class="account-num">${a.accountNumber}</span></td>
      <td>${a.customerName}</td>
      <td><span class="badge badge-${a.accountType.toLowerCase()}">${a.accountType}</span></td>
      <td class="mono">${formatCurrency(a.balance)}</td>
      <td>${a.email}</td>
      <td>${a.phone}</td>
      <td><span class="badge badge-${a.status.toLowerCase()}">${a.status}</span></td>
      <td><button class="btn btn-sm btn-outline" onclick="showDetail('${a.accountNumber}')">View</button></td>
    </tr>`).join('');
}

// ── Account Detail Modal ──────────────────────────────────────────────────────
async function showDetail(accNum) {
  try {
    const d = await apiGet({ action: 'searchAccount', accountNumber: accNum });
    if (!d.success || !d.account) { showToast('Account not found.', 'error'); return; }
    const a = d.account;
    setEl('detail-accnum',  a.accountNumber);
    setEl('detail-name',    a.customerName);
    setEl('detail-email',   a.email);
    setEl('detail-phone',   a.phone);
    setEl('detail-address', a.address);
    setEl('detail-balance', formatCurrency(a.balance));
    setEl('detail-created', formatDate(a.createdAt));
    document.getElementById('detail-type').innerHTML   = `<span class="badge badge-${a.accountType.toLowerCase()}">${a.accountType}</span>`;
    document.getElementById('detail-status').innerHTML = `<span class="badge badge-${a.status.toLowerCase()}">${a.status}</span>`;
    loadTxnHistory(a.accountNumber);
    document.getElementById('modal-overlay').style.display = 'flex';
  } catch { showToast('Error loading account.', 'error'); }
}

async function loadTxnHistory(accNum) {
  const c = document.getElementById('txn-history');
  c.innerHTML = '<div class="loading-wrap"><div class="spinner"></div></div>';
  try {
    const d = await apiGet({ action: 'getTransactions', accountNumber: accNum });
    if (d.success && d.transactions.length) {
      c.innerHTML = `<div class="table-wrap"><table>
        <thead><tr><th>Transaction ID</th><th>Type</th><th>Amount</th><th>Balance After</th><th>Date</th></tr></thead>
        <tbody>${d.transactions.map(t => `
          <tr>
            <td class="mono" style="font-size:.75rem">${t.transactionId}</td>
            <td><span class="badge badge-${t.transactionType.replace(/ /g,'').toLowerCase()}">${t.transactionType}</span></td>
            <td class="mono">${formatCurrency(t.amount)}</td>
            <td class="mono">${formatCurrency(t.balanceAfter)}</td>
            <td>${formatDate(t.transactionDate)}</td>
          </tr>`).join('')}
        </tbody></table></div>`;
    } else {
      c.innerHTML = '<div class="empty-state"><div class="icon">📋</div><p>No transactions yet.</p></div>';
    }
  } catch { c.innerHTML = '<p style="color:var(--ruby);padding:20px">Error loading transactions.</p>'; }
}

document.getElementById('modal-close')?.addEventListener('click', closeModal);
document.getElementById('modal-overlay')?.addEventListener('click', function (e) {
  if (e.target === this) closeModal();
});
function closeModal() { document.getElementById('modal-overlay').style.display = 'none'; }

// ── Deposit ───────────────────────────────────────────────────────────────────
document.getElementById('form-deposit')?.addEventListener('submit', async function (e) {
  e.preventDefault(); clearErrors();
  const accountNumber = getVal('dep-accnum');
  const amount        = getVal('dep-amount');
  let valid = true;
  if (!accountNumber)                         { showFE('dep-accnum', 'Account number required.'); valid = false; }
  if (!amount || isNaN(amount) || +amount<=0) { showFE('dep-amount', 'Enter a valid positive amount.'); valid = false; }
  if (!valid) return;

  const btn = this.querySelector('[type=submit]');
  setLoading(btn, true);
  try {
    const d = await apiPost({ action: 'deposit', accountNumber: accountNumber.toUpperCase(), amount });
    if (d.success) {
      showAlert('dep-alert', 'success', `✅ ${d.message} New balance: <strong class="mono">${formatCurrency(d.newBalance)}</strong>`);
      showToast(d.message, 'success');
      document.getElementById('dep-amount').value = '';
      document.getElementById('dep-account-preview').innerHTML = '';
    } else { showAlert('dep-alert', 'error', '❌ ' + d.message); }
  } catch { showAlert('dep-alert', 'error', '❌ Server error.'); }
  finally   { setLoading(btn, false); }
});

document.getElementById('dep-accnum')?.addEventListener('blur', async function () {
  const v = this.value.trim().toUpperCase();
  if (!v) return;
  try {
    const d = await apiGet({ action: 'searchAccount', accountNumber: v });
    if (d.success && d.account) {
      const a = d.account;
      document.getElementById('dep-account-preview').innerHTML = `
        <div class="amount-display">
          <div class="label">Current Balance — ${a.customerName}</div>
          <div class="value">${formatCurrency(a.balance)}</div>
        </div>
        <div style="margin-bottom:14px">
          <span class="badge badge-${a.accountType.toLowerCase()}">${a.accountType}</span>
          <span class="badge badge-${a.status.toLowerCase()}" style="margin-left:6px">${a.status}</span>
        </div>`;
    } else { document.getElementById('dep-account-preview').innerHTML = ''; }
  } catch {}
});

// ── Withdraw ──────────────────────────────────────────────────────────────────
document.getElementById('form-withdraw')?.addEventListener('submit', async function (e) {
  e.preventDefault(); clearErrors();
  const accountNumber = getVal('wd-accnum');
  const amount        = getVal('wd-amount');
  let valid = true;
  if (!accountNumber)                         { showFE('wd-accnum', 'Account number required.'); valid = false; }
  if (!amount || isNaN(amount) || +amount<=0) { showFE('wd-amount', 'Enter a valid positive amount.'); valid = false; }
  if (!valid) return;

  const btn = this.querySelector('[type=submit]');
  setLoading(btn, true);
  try {
    const d = await apiPost({ action: 'withdraw', accountNumber: accountNumber.toUpperCase(), amount });
    if (d.success) {
      showAlert('wd-alert', 'success', `✅ ${d.message} New balance: <strong class="mono">${formatCurrency(d.newBalance)}</strong>`);
      showToast(d.message, 'success');
      document.getElementById('wd-amount').value = '';
      document.getElementById('wd-account-preview').innerHTML = '';
    } else { showAlert('wd-alert', 'error', '❌ ' + d.message); }
  } catch { showAlert('wd-alert', 'error', '❌ Server error.'); }
  finally   { setLoading(btn, false); }
});

document.getElementById('wd-accnum')?.addEventListener('blur', async function () {
  const v = this.value.trim().toUpperCase();
  if (!v) return;
  try {
    const d = await apiGet({ action: 'searchAccount', accountNumber: v });
    if (d.success && d.account) {
      const a = d.account;
      document.getElementById('wd-account-preview').innerHTML = `
        <div class="amount-display">
          <div class="label">Current Balance — ${a.customerName}</div>
          <div class="value">${formatCurrency(a.balance)}</div>
        </div>
        <div style="margin-bottom:14px">
          <span class="badge badge-${a.accountType.toLowerCase()}">${a.accountType}</span>
          <span class="badge badge-${a.status.toLowerCase()}" style="margin-left:6px">${a.status}</span>
        </div>`;
    } else { document.getElementById('wd-account-preview').innerHTML = ''; }
  } catch {}
});

// ── Status Management ─────────────────────────────────────────────────────────
document.getElementById('btn-load-status')?.addEventListener('click', async () => {
  const accNum = getVal('status-accnum');
  if (!accNum) { showToast('Enter an account number.', 'warning'); return; }
  try {
    const d = await apiGet({ action: 'searchAccount', accountNumber: accNum.toUpperCase() });
    if (d.success && d.account) {
      const a = d.account;
      document.getElementById('status-preview').innerHTML = `
        <div class="card" style="margin-top:20px">
          <div class="card-header">
            <div>
              <div class="card-title">${a.customerName}</div>
              <div class="card-subtitle mono">${a.accountNumber}</div>
            </div>
            <span class="badge badge-${a.status.toLowerCase()}">${a.status}</span>
          </div>
          <div class="account-detail-grid">
            <div class="detail-row">
              <span class="detail-label">Account Type</span>
              <span class="detail-value"><span class="badge badge-${a.accountType.toLowerCase()}">${a.accountType}</span></span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Balance</span>
              <span class="detail-value balance-value">${formatCurrency(a.balance)}</span>
            </div>
          </div>
          <div class="divider"></div>
          <div style="display:flex;gap:12px;flex-wrap:wrap">
            ${a.status !== 'Active'   ? `<button class="btn btn-success"   onclick="updateStatus('${a.accountNumber}','Active')">✅ Activate</button>`    : ''}
            ${a.status !== 'Inactive' ? `<button class="btn btn-secondary" onclick="updateStatus('${a.accountNumber}','Inactive')">⏸ Deactivate</button>` : ''}
            ${a.status !== 'Closed'   ? `<button class="btn btn-danger"    onclick="updateStatus('${a.accountNumber}','Closed')">🔒 Close Account</button>`
                                      : '<span style="color:var(--ruby);font-size:.85rem">This account is permanently closed.</span>'}
          </div>
        </div>`;
    } else { showToast('Account not found.', 'error'); }
  } catch { showToast('Error loading account.', 'error'); }
});

async function updateStatus(accountNumber, status) {
  if (status === 'Closed' && !confirm('Close this account permanently? This cannot be undone.')) return;
  try {
    const d = await apiPost({ action: 'updateStatus', accountNumber, status });
    if (d.success) {
      showToast(d.message, 'success');
      document.getElementById('status-accnum').value = accountNumber;
      document.getElementById('btn-load-status').click();
    } else { showToast(d.message, 'error'); }
  } catch { showToast('Error updating status.', 'error'); }
}

function quickNavigate(page) { navigateTo(page); }

// ── Utilities ─────────────────────────────────────────────────────────────────
function getVal(id)     { return (document.getElementById(id)?.value || '').trim(); }
function setEl(id, val) { const el = document.getElementById(id); if (el) el.textContent = val; }

function formatCurrency(n) {
  return '₹' + (parseFloat(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatDate(s) {
  if (!s) return '—';
  return new Date(s).toLocaleString('en-IN', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });
}

function validEmail(e) { return /^[\w._%+\-]+@[\w.\-]+\.[a-zA-Z]{2,}$/.test(e); }
function validPhone(p) { return /^[+\d][\d\s\-(). ]{6,19}$/.test(p); }

function showFE(id, msg) {
  document.getElementById(id)?.classList.add('error');
  const e = document.getElementById(id + '-err');
  if (e) e.textContent = msg;
}

function clearErrors() {
  document.querySelectorAll('input.error, select.error').forEach(el => el.classList.remove('error'));
  document.querySelectorAll('.field-error').forEach(el => el.textContent = '');
}

function showAlert(id, type, html) {
  const el = document.getElementById(id);
  if (!el) return;
  el.className = `alert alert-${type}`;
  el.innerHTML = html;
  el.style.display = 'flex';
  setTimeout(() => { if (el) el.style.display = 'none'; }, 8000);
}

function setLoading(btn, loading) {
  if (!btn) return;
  btn.disabled = loading;
  btn._orig = btn._orig || btn.innerHTML;
  btn.innerHTML = loading ? '<span style="opacity:.6">Processing...</span>' : btn._orig;
}