package com.bank.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String DB_URL      = "jdbc:mysql://localhost:3306/banking_system"
                                            + "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String DB_USER     = "root";       // change to your MySQL username
    private static final String DB_PASSWORD = "1234";   // change to your MySQL password
    private static final String DRIVER      = "com.mysql.cj.jdbc.Driver";

    private static DatabaseConnection instance;

    private DatabaseConnection() {
        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL JDBC Driver not found.", e);
        }
    }

    public static synchronized DatabaseConnection getInstance() {
        if (instance == null) instance = new DatabaseConnection();
        return instance;
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    public static Connection connect() throws SQLException {
        return getInstance().getConnection();
    }
}