package com.bank.servlet;

import com.bank.dao.AccountDAO;
import com.bank.model.Account;
import com.bank.model.Transaction;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/api/account")
public class AccountServlet extends HttpServlet {

    private final AccountDAO dao  = new AccountDAO();
    private final Gson       gson = new GsonBuilder()
                                        .setDateFormat("yyyy-MM-dd HH:mm:ss")
                                        .create();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        res.setContentType("application/json;charset=UTF-8");
        res.setHeader("Access-Control-Allow-Origin", "*");
        PrintWriter out = res.getWriter();
        Map<String, Object> result = new HashMap<>();
        String action = req.getParameter("action");

        try {
            switch (action == null ? "" : action) {

                case "dashboard": {
                    int[]      stats = dao.getDashboardStats();
                    BigDecimal funds = dao.getTotalFunds();
                    result.put("totalAccounts",    stats[0]);
                    result.put("activeAccounts",   stats[1]);
                    result.put("inactiveAccounts", stats[2]);
                    result.put("closedAccounts",   stats[3]);
                    result.put("totalFunds",       funds);
                    result.put("success", true);
                    break;
                }

                case "searchAccount": {
                    String accNum = req.getParameter("accountNumber");
                    String name   = req.getParameter("customerName");

                    if (accNum != null && !accNum.trim().isEmpty()) {
                        Account a = dao.getAccountByNumber(accNum.trim().toUpperCase());
                        if (a != null) {
                            result.put("account", a);
                            result.put("success", true);
                        } else {
                            result.put("success", false);
                            result.put("message", "No account found with that number.");
                        }
                    } else if (name != null && !name.trim().isEmpty()) {
                        List<Account> list = dao.searchByName(name.trim());
                        result.put("accounts", list);
                        result.put("success", true);
                    } else {
                        List<Account> list = dao.getAllAccounts();
                        result.put("accounts", list);
                        result.put("success", true);
                    }
                    break;
                }

                case "getTransactions": {
                    String accNum = req.getParameter("accountNumber");
                    if (accNum == null || accNum.trim().isEmpty()) {
                        result.put("success", false);
                        result.put("message", "Account number required.");
                        break;
                    }
                    List<Transaction> txns = dao.getTransactions(accNum.trim().toUpperCase());
                    result.put("transactions", txns);
                    result.put("success", true);
                    break;
                }

                default:
                    result.put("success", false);
                    result.put("message", "Unknown action.");
            }
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", e.getMessage());
        }

        out.print(gson.toJson(result));
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        res.setContentType("application/json;charset=UTF-8");
        res.setHeader("Access-Control-Allow-Origin", "*");
        req.setCharacterEncoding("UTF-8");
        PrintWriter out = res.getWriter();
        Map<String, Object> result = new HashMap<>();
        String action = req.getParameter("action");

        try {
            switch (action == null ? "" : action) {

                case "createAccount": {
                    String name    = require(req, "customerName");
                    String email   = require(req, "email");
                    String phone   = require(req, "phone");
                    String address = require(req, "address");
                    String type    = require(req, "accountType");
                    String dep     = require(req, "initialDeposit");

                    validateEmail(email);
                    validatePhone(phone);
                    BigDecimal deposit = parseMoney(dep, "Initial deposit");
                    if (deposit.compareTo(BigDecimal.ZERO) < 0)
                        throw new IllegalArgumentException("Initial deposit cannot be negative.");

                    String  accNum  = dao.generateAccountNumber();
                    Account account = new Account(accNum, name, email, phone, address, type, deposit, "Active");
                    boolean ok      = dao.createAccount(account);
                    result.put("success",       ok);
                    result.put("accountNumber", accNum);
                    result.put("message", ok ? "Account created successfully!" : "Failed to create account.");
                    break;
                }

                case "deposit": {
                    String    accNum = require(req, "accountNumber").toUpperCase();
                    BigDecimal amount = parseMoney(require(req, "amount"), "Deposit amount");
                    dao.deposit(accNum, amount);
                    Account a = dao.getAccountByNumber(accNum);
                    result.put("success",    true);
                    result.put("message",    "Deposit of Rs." + amount + " successful.");
                    result.put("newBalance", a.getBalance());
                    break;
                }

                case "withdraw": {
                    String    accNum = require(req, "accountNumber").toUpperCase();
                    BigDecimal amount = parseMoney(require(req, "amount"), "Withdrawal amount");
                    dao.withdraw(accNum, amount);
                    Account a = dao.getAccountByNumber(accNum);
                    result.put("success",    true);
                    result.put("message",    "Withdrawal of Rs." + amount + " successful.");
                    result.put("newBalance", a.getBalance());
                    break;
                }

                case "updateStatus": {
                    String accNum = require(req, "accountNumber").toUpperCase();
                    String status = require(req, "status");
                    if (!status.matches("Active|Inactive|Closed"))
                        throw new IllegalArgumentException("Invalid status value.");
                    boolean ok = dao.updateStatus(accNum, status);
                    result.put("success", ok);
                    result.put("message", ok ? "Status updated to " + status + "." : "Account not found.");
                    break;
                }

                default:
                    result.put("success", false);
                    result.put("message", "Unknown action.");
            }
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", e.getMessage());
        }

        out.print(gson.toJson(result));
    }

    private String require(HttpServletRequest req, String name) {
        String v = req.getParameter(name);
        if (v == null || v.trim().isEmpty())
            throw new IllegalArgumentException("'" + name + "' is required.");
        return v.trim();
    }

    private BigDecimal parseMoney(String value, String label) {
        try { return new BigDecimal(value); }
        catch (NumberFormatException e) {
            throw new IllegalArgumentException(label + " must be a valid number.");
        }
    }

    private void validateEmail(String email) {
        if (!email.matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$"))
            throw new IllegalArgumentException("Invalid email address format.");
    }

    private void validatePhone(String phone) {
        if (!phone.matches("^[+\\d][\\d\\s\\-().]{6,19}$"))
            throw new IllegalArgumentException("Invalid phone number format.");
    }
}