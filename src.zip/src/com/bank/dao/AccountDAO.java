package com.bank.dao;

import com.bank.model.Account;
import com.bank.model.Transaction;
import com.bank.util.DatabaseConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AccountDAO {

    public String generateAccountNumber() throws SQLException {
        String sql = "SELECT MAX(CAST(SUBSTRING(account_number,4) AS UNSIGNED)) FROM accounts";
        try (Connection con = DatabaseConnection.connect();
             Statement  st  = con.createStatement();
             ResultSet  rs  = st.executeQuery(sql)) {
            long next = 1;
            if (rs.next() && rs.getString(1) != null)
                next = rs.getLong(1) + 1;
            return String.format("ACC%010d", next);
        }
    }

    private String generateTransactionId() {
        String ts   = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        int    rand = new Random().nextInt(9000) + 1000;
        return "TXN" + ts + rand;
    }

    public boolean createAccount(Account account) throws SQLException {
        String sql = "INSERT INTO accounts "
                   + "(account_number, customer_name, email, phone, address, account_type, balance, status) "
                   + "VALUES (?,?,?,?,?,?,?,?)";
        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, account.getAccountNumber());
            ps.setString(2, account.getCustomerName());
            ps.setString(3, account.getEmail());
            ps.setString(4, account.getPhone());
            ps.setString(5, account.getAddress());
            ps.setString(6, account.getAccountType());
            ps.setBigDecimal(7, account.getBalance());
            ps.setString(8, account.getStatus());
            if (ps.executeUpdate() > 0) {
                recordTransaction(account.getAccountNumber(), "Account Created",
                        account.getBalance(), account.getBalance(), "Initial deposit");
                return true;
            }
            return false;
        }
    }

    public Account getAccountByNumber(String accountNumber) throws SQLException {
        String sql = "SELECT * FROM accounts WHERE account_number = ?";
        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, accountNumber);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public List<Account> searchByName(String name) throws SQLException {
        String sql = "SELECT * FROM accounts WHERE customer_name LIKE ? ORDER BY created_at DESC";
        List<Account> list = new ArrayList<>();
        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + name + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    public List<Account> getAllAccounts() throws SQLException {
        String sql = "SELECT * FROM accounts ORDER BY created_at DESC";
        List<Account> list = new ArrayList<>();
        try (Connection con = DatabaseConnection.connect();
             Statement  st  = con.createStatement();
             ResultSet  rs  = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public boolean deposit(String accountNumber, BigDecimal amount) throws SQLException {
        Account account = getAccountByNumber(accountNumber);
        if (account == null)
            throw new SQLException("Account not found.");
        if (!"Active".equals(account.getStatus()))
            throw new SQLException("Account is " + account.getStatus() + ". Transactions not allowed.");
        if (amount.compareTo(BigDecimal.ZERO) <= 0)
            throw new SQLException("Deposit amount must be positive.");

        String sql = "UPDATE accounts SET balance = balance + ? WHERE account_number = ?";
        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBigDecimal(1, amount);
            ps.setString(2, accountNumber);
            ps.executeUpdate();
        }
        BigDecimal newBalance = account.getBalance().add(amount);
        recordTransaction(accountNumber, "Deposit", amount, newBalance, "Deposit");
        return true;
    }

    public boolean withdraw(String accountNumber, BigDecimal amount) throws SQLException {
        Account account = getAccountByNumber(accountNumber);
        if (account == null)
            throw new SQLException("Account not found.");
        if (!"Active".equals(account.getStatus()))
            throw new SQLException("Account is " + account.getStatus() + ". Transactions not allowed.");
        if (amount.compareTo(BigDecimal.ZERO) <= 0)
            throw new SQLException("Withdrawal amount must be positive.");

        BigDecimal minBalance = "Savings".equals(account.getAccountType())
                ? new BigDecimal("500.00") : BigDecimal.ZERO;

        BigDecimal remaining = account.getBalance().subtract(amount);
        if (remaining.compareTo(minBalance) < 0)
            throw new SQLException("Insufficient funds. " +
                    (minBalance.compareTo(BigDecimal.ZERO) > 0
                     ? "Savings accounts must maintain a minimum balance of Rs." + minBalance + "."
                     : "Balance cannot go below zero."));

        String sql = "UPDATE accounts SET balance = balance - ? WHERE account_number = ?";
        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBigDecimal(1, amount);
            ps.setString(2, accountNumber);
            ps.executeUpdate();
        }
        recordTransaction(accountNumber, "Withdrawal", amount, remaining, "Withdrawal");
        return true;
    }

    public boolean updateStatus(String accountNumber, String status) throws SQLException {
        String sql = "UPDATE accounts SET status = ? WHERE account_number = ?";
        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, accountNumber);
            return ps.executeUpdate() > 0;
        }
    }

    public void recordTransaction(String accountNumber, String type,
                                  BigDecimal amount, BigDecimal balanceAfter,
                                  String description) throws SQLException {
        String sql = "INSERT INTO transactions "
                   + "(transaction_id, account_number, transaction_type, amount, balance_after, description) "
                   + "VALUES (?,?,?,?,?,?)";
        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, generateTransactionId());
            ps.setString(2, accountNumber);
            ps.setString(3, type);
            ps.setBigDecimal(4, amount);
            ps.setBigDecimal(5, balanceAfter);
            ps.setString(6, description);
            ps.executeUpdate();
        }
    }

    public List<Transaction> getTransactions(String accountNumber) throws SQLException {
        String sql = "SELECT * FROM transactions WHERE account_number = ? "
                   + "ORDER BY transaction_date DESC LIMIT 20";
        List<Transaction> list = new ArrayList<>();
        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, accountNumber);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Transaction t = new Transaction();
                    t.setId(rs.getInt("id"));
                    t.setTransactionId(rs.getString("transaction_id"));
                    t.setAccountNumber(rs.getString("account_number"));
                    t.setTransactionType(rs.getString("transaction_type"));
                    t.setAmount(rs.getBigDecimal("amount"));
                    t.setBalanceAfter(rs.getBigDecimal("balance_after"));
                    t.setDescription(rs.getString("description"));
                    t.setTransactionDate(rs.getTimestamp("transaction_date"));
                    list.add(t);
                }
            }
        }
        return list;
    }

    public int[] getDashboardStats() throws SQLException {
        String sql = "SELECT COUNT(*) total, "
                   + "SUM(status='Active') active, "
                   + "SUM(status='Inactive') inactive, "
                   + "SUM(status='Closed') closed FROM accounts";
        try (Connection con = DatabaseConnection.connect();
             Statement  st  = con.createStatement();
             ResultSet  rs  = st.executeQuery(sql)) {
            if (rs.next())
                return new int[]{ rs.getInt("total"), rs.getInt("active"),
                                  rs.getInt("inactive"), rs.getInt("closed") };
        }
        return new int[]{0, 0, 0, 0};
    }

    public BigDecimal getTotalFunds() throws SQLException {
        String sql = "SELECT COALESCE(SUM(balance),0) FROM accounts WHERE status != 'Closed'";
        try (Connection con = DatabaseConnection.connect();
             Statement  st  = con.createStatement();
             ResultSet  rs  = st.executeQuery(sql)) {
            return rs.next() ? rs.getBigDecimal(1) : BigDecimal.ZERO;
        }
    }

    private Account mapRow(ResultSet rs) throws SQLException {
        Account a = new Account();
        a.setId(rs.getInt("id"));
        a.setAccountNumber(rs.getString("account_number"));
        a.setCustomerName(rs.getString("customer_name"));
        a.setEmail(rs.getString("email"));
        a.setPhone(rs.getString("phone"));
        a.setAddress(rs.getString("address"));
        a.setAccountType(rs.getString("account_type"));
        a.setBalance(rs.getBigDecimal("balance"));
        a.setStatus(rs.getString("status"));
        a.setCreatedAt(rs.getTimestamp("created_at"));
        a.setUpdatedAt(rs.getTimestamp("updated_at"));
        return a;
    }
}