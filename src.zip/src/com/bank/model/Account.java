package com.bank.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Account {

    private int        id;
    private String     accountNumber;
    private String     customerName;
    private String     email;
    private String     phone;
    private String     address;
    private String     accountType;
    private BigDecimal balance;
    private String     status;
    private Timestamp  createdAt;
    private Timestamp  updatedAt;

    public Account() {}

    public Account(String accountNumber, String customerName, String email,
                   String phone, String address, String accountType,
                   BigDecimal balance, String status) {
        this.accountNumber = accountNumber;
        this.customerName  = customerName;
        this.email         = email;
        this.phone         = phone;
        this.address       = address;
        this.accountType   = accountType;
        this.balance       = balance;
        this.status        = status;
    }

    public int    getId()                           { return id; }
    public void   setId(int id)                     { this.id = id; }

    public String getAccountNumber()                { return accountNumber; }
    public void   setAccountNumber(String a)        { this.accountNumber = a; }

    public String getCustomerName()                 { return customerName; }
    public void   setCustomerName(String c)         { this.customerName = c; }

    public String getEmail()                        { return email; }
    public void   setEmail(String email)            { this.email = email; }

    public String getPhone()                        { return phone; }
    public void   setPhone(String phone)            { this.phone = phone; }

    public String getAddress()                      { return address; }
    public void   setAddress(String address)        { this.address = address; }

    public String getAccountType()                  { return accountType; }
    public void   setAccountType(String a)          { this.accountType = a; }

    public BigDecimal getBalance()                  { return balance; }
    public void       setBalance(BigDecimal b)      { this.balance = b; }

    public String getStatus()                       { return status; }
    public void   setStatus(String status)          { this.status = status; }

    public Timestamp getCreatedAt()                 { return createdAt; }
    public void      setCreatedAt(Timestamp t)      { this.createdAt = t; }

    public Timestamp getUpdatedAt()                 { return updatedAt; }
    public void      setUpdatedAt(Timestamp t)      { this.updatedAt = t; }
}