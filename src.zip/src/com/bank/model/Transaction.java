package com.bank.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Transaction {

    private int        id;
    private String     transactionId;
    private String     accountNumber;
    private String     transactionType;
    private BigDecimal amount;
    private BigDecimal balanceAfter;
    private String     description;
    private Timestamp  transactionDate;

    public Transaction() {}

    public Transaction(String transactionId, String accountNumber,
                       String transactionType, BigDecimal amount,
                       BigDecimal balanceAfter, String description) {
        this.transactionId   = transactionId;
        this.accountNumber   = accountNumber;
        this.transactionType = transactionType;
        this.amount          = amount;
        this.balanceAfter    = balanceAfter;
        this.description     = description;
    }

    public int    getId()                           { return id; }
    public void   setId(int id)                     { this.id = id; }

    public String getTransactionId()                { return transactionId; }
    public void   setTransactionId(String t)        { this.transactionId = t; }

    public String getAccountNumber()                { return accountNumber; }
    public void   setAccountNumber(String a)        { this.accountNumber = a; }

    public String getTransactionType()              { return transactionType; }
    public void   setTransactionType(String t)      { this.transactionType = t; }

    public BigDecimal getAmount()                   { return amount; }
    public void       setAmount(BigDecimal a)       { this.amount = a; }

    public BigDecimal getBalanceAfter()             { return balanceAfter; }
    public void       setBalanceAfter(BigDecimal b) { this.balanceAfter = b; }

    public String getDescription()                  { return description; }
    public void   setDescription(String d)          { this.description = d; }

    public Timestamp getTransactionDate()           { return transactionDate; }
    public void      setTransactionDate(Timestamp t){ this.transactionDate = t; }
}